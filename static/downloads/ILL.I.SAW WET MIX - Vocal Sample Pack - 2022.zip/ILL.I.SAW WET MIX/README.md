# MC SCRPT

### Big up Junglists!

If you plan on using or have used these audio tacks, please read the following.
First off, I really appreciate anyone who downloads these audio track and shares it with their producer friends! With that being said, credit would be much appreciated. It would mean the world to me!

## Featuring

- ILL.I.SAW
- Al Gee
- Hevy

---

Sample Pack 2022
